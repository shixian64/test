# Android Log Analyzer - Windows Python版本使用指南

## 🎯 系统要求

- Windows 7/8/10/11 (32位或64位)
- Python 3.7+ (从 https://python.org 下载)
- 至少100MB可用磁盘空间
- 512MB可用内存

## 📦 安装步骤

### 步骤1: 安装Python
1. 访问 https://python.org/downloads/
2. 下载最新的Python 3.x版本
3. 运行安装程序
4. **重要**: 勾选 "Add Python to PATH" 选项
5. 点击 "Install Now"

### 步骤2: 安装Android Log Analyzer
1. 解压下载的zip文件到任意目录
2. 双击 `install.bat` 运行安装脚本
3. 等待依赖安装完成

## 🚀 使用方法

### 方法1: 图形界面（推荐）
```
双击 AndroidLogAnalyzer.bat
```

### 方法2: 命令行分析
```cmd
analyze_log.bat your_log_file.log
```

### 方法3: 直接使用Python
```cmd
# 激活虚拟环境
venv\Scripts\activate

# 运行程序
python main_app.py
python main_app.py your_log_file.log
```

## 🔍 功能特点

✅ **完整功能**: 与可执行文件版本功能完全相同
✅ **智能分析**: 13种Android问题类型检测
✅ **多格式支持**: .log, .txt, .gz, .zip文件
✅ **SPRD平台**: 专门的芯片组分析支持
✅ **实时更新**: 可以轻松更新到最新版本

## 🛠️ 故障排除

### 常见问题

**Q: 提示"Python不是内部或外部命令"**
A: Python未正确安装或未添加到PATH。重新安装Python并勾选"Add Python to PATH"

**Q: 安装依赖失败**
A: 检查网络连接，或使用国内镜像：
```cmd
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple/
```

**Q: 程序无法启动**
A: 确保已运行install.bat完成安装，然后使用AndroidLogAnalyzer.bat启动

**Q: 分析结果为空**
A: 检查日志文件格式，使用sample.log测试程序是否正常工作

### 获取帮助
```cmd
python main_app.py --help
```

## 📈 优势对比

| 特性 | Python版本 | 可执行文件版本 |
|------|------------|----------------|
| 文件大小 | ~10MB | ~7MB |
| 安装复杂度 | 需要Python | 即开即用 |
| 更新便利性 | ✅ 容易 | 需要重新下载 |
| 自定义能力 | ✅ 可修改 | 固定功能 |
| 系统兼容性 | 更广泛 | 仅64位Windows |

## 🔄 更新方法

1. 下载新版本的zip文件
2. 备份当前的配置文件（如果有）
3. 解压新版本覆盖旧文件
4. 运行install.bat更新依赖

## 📞 技术支持

- 项目主页: https://github.com/shixian64/test
- 问题反馈: https://github.com/shixian64/test/issues
- Python官方: https://python.org

---

**🎯 享受强大的Android日志分析功能！**
